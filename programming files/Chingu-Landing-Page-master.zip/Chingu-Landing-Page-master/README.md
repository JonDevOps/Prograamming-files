# W3Develops
Hey guys! Today we'll be working on creating a landing page to host on github pages. Check out the branches to get started , then add what needs to be added until the pages is completed. 

